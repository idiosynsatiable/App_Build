# Architecture Documentation

## Overview

**A-1 Blueprint Builder** is a production-ready Next.js web application that implements the A-1 ROUTER-PRIME BLUEPRINT BUILDER v1.3 workflow. It provides a local-first interface for running the master script against an LLM and enforces anti-cyclical termination rules.

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                         Browser                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  React UI (app/page.tsx)                              │  │
│  │  - Intake form                                        │  │
│  │  - Output display                                     │  │
│  │  - History management (localStorage)                 │  │
│  └───────────────┬───────────────────────────────────────┘  │
└──────────────────┼──────────────────────────────────────────┘
                   │ POST /api/run
                   │ { intake, maxTokens? }
                   ▼
┌─────────────────────────────────────────────────────────────┐
│                    Next.js Server                           │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  API Route (app/api/run/route.ts)                    │  │
│  │  1. Validate input (Zod)                             │  │
│  │  2. Safety scan (forbidden content)                  │  │
│  │  3. Load master script                               │  │
│  │  4. Call LLM (lib/llm.ts)                            │  │
│  │  5. Validate output (terminal state)                 │  │
│  │  6. Return result                                    │  │
│  └───────────────┬───────────────────────────────────────┘  │
└──────────────────┼──────────────────────────────────────────┘
                   │ OpenAI-compatible API
                   │ { model, messages, temperature, max_tokens }
                   ▼
┌─────────────────────────────────────────────────────────────┐
│                    LLM Provider                             │
│  - OpenAI (default)                                         │
│  - OpenRouter                                               │
│  - Other OpenAI-compatible APIs                             │
└─────────────────────────────────────────────────────────────┘
```

## Component Breakdown

### Frontend (`app/page.tsx`)

**Responsibilities:**
- Render intake form
- Handle user input
- Call `/api/run` endpoint
- Display results
- Manage run history in localStorage
- Download outputs as Markdown

**State Management:**
- `intake`: User input text
- `loading`: Request in progress
- `result`: Current run result
- `error`: Error message
- `history`: Array of past runs (max 20)

**Key Features:**
- Real-time validation
- History persistence (localStorage)
- One-click download (.md)
- Click-to-reload from history

### API Route (`app/api/run/route.ts`)

**Responsibilities:**
- Validate request body (Zod schema)
- Perform safety checks
- Load master script from file
- Invoke LLM
- Validate terminal output
- Return structured response

**Validation Layers:**

1. **Input Validation (Zod)**
   - `intake`: string, min 50 chars
   - `maxTokens`: optional number, 256-4000

2. **Safety Scan**
   - Blocks forbidden content patterns
   - Returns 403 if detected

3. **Output Validation**
   - Ensures exactly ONE terminal state:
     - `NEXT FILE BATCH` OR
     - `FINAL SHIP PACKAGE`
   - Returns 500 if invalid

**Response Format:**
```json
{
  "output": "...",
  "model": "gpt-4.1-mini",
  "timestamp": "2026-01-29T12:00:00.000Z"
}
```

### LLM Client (`lib/llm.ts`)

**Responsibilities:**
- Load environment variables
- Construct OpenAI-compatible request
- Handle API errors
- Parse response

**Configuration:**
- `OPENAI_API_KEY` (required)
- `OPENAI_MODEL` (required)
- `OPENAI_BASE_URL` (optional, defaults to OpenAI)

**Request Parameters:**
- `temperature`: 0.2 (deterministic)
- `max_tokens`: 2500 (default) or user-specified

### Master Script (`prompts/a1_master_script_v1_3.txt`)

**Purpose:**
- System prompt for LLM
- Defines workflow and personas
- Enforces anti-cyclical rules
- Specifies output format

**Key Sections:**
1. Cost-control rules
2. Compiler output contract
3. Termination rules
4. Router-Prime orchestration
5. Persona specifications
6. Integrator logic
7. Release gates

## Data Flow

### Successful Run

```
1. User pastes INTAKE → app/page.tsx
2. User clicks "Run" → POST /api/run
3. API validates input → Zod schema
4. API scans for forbidden content → PASS
5. API loads master script → prompts/a1_master_script_v1_3.txt
6. API calls LLM → lib/llm.ts
7. LLM returns output → { output, model }
8. API validates terminal state → PASS
9. API returns result → { output, model, timestamp }
10. UI displays result → app/page.tsx
11. UI saves to history → localStorage
12. User downloads .md → browser download
```

### Error Scenarios

**Input Validation Failure:**
- Status: 400
- Response: `{ error: "Validation failed", details: {...} }`

**Safety Scan Failure:**
- Status: 403
- Response: `{ error: "Refused: disallowed content detected (\"...\")" }`

**LLM API Failure:**
- Status: 500
- Response: `{ error: "LLM error 401: ..." }`

**Terminal State Validation Failure:**
- Status: 500
- Response: `{ error: "Invalid output: must include EXACTLY ONE of...", raw: "..." }`

## Security

### Input Validation
- Zod schema enforcement
- Minimum length check (50 chars)
- Type safety (TypeScript)

### Safety Checks
- Forbidden content patterns:
  - malware
  - hacking
  - credential theft
  - stealth exfiltration
  - illicit command-and-control
  - ToS evasion
  - account abuse
  - pornography

### Secrets Management
- Environment variables only
- Never committed to repo
- `.env.local` in `.gitignore`

### API Security
- Server-side validation
- Error message sanitization
- No client-side secrets

## Performance

### Optimization Strategies
- Static generation for UI
- Server-side API routes
- Minimal client-side JavaScript
- localStorage for history (no DB overhead)

### Resource Limits
- Max tokens: 4000 (configurable)
- History size: 20 runs (auto-pruned)
- Request timeout: 30s (default)

## Deployment

### Supported Platforms
- **Vercel** (recommended)
- **Netlify**
- **Railway**
- **Fly.io**
- **Docker** (self-hosted)

### Environment Variables
```bash
OPENAI_API_KEY=sk-...          # Required
OPENAI_MODEL=gpt-4.1-mini      # Required
OPENAI_BASE_URL=https://...    # Optional
```

### Build Process
```bash
pnpm install   # Install dependencies
pnpm lint      # Lint code
pnpm build     # Build for production
pnpm start     # Start production server
```

## Testing

### Type Safety
```bash
pnpm exec tsc --noEmit
```

### Linting
```bash
pnpm lint
```

### Build Verification
```bash
pnpm build
```

### Manual Testing Checklist
- [ ] Paste INTAKE and click Run
- [ ] Verify output contains exactly one terminal state
- [ ] Download output as .md
- [ ] Check history persistence (reload page)
- [ ] Test error handling (empty input, invalid API key)
- [ ] Test safety checks (paste forbidden content)

## Maintenance

### Adding New Safety Rules
Edit `FORBIDDEN` array in `app/api/run/route.ts`:
```typescript
const FORBIDDEN = [
  "malware",
  "new-forbidden-term"
];
```

### Updating Master Script
Replace content in `prompts/a1_master_script_v1_3.txt` with new version.

### Changing LLM Provider
Set `OPENAI_BASE_URL` to provider's base URL:
```bash
# OpenRouter
OPENAI_BASE_URL=https://openrouter.ai/api/v1

# Local LLM
OPENAI_BASE_URL=http://localhost:11434/v1
```

### Monitoring
- Check server logs for API errors
- Monitor LLM API usage/costs
- Track response times
- Review safety scan rejections

## Future Enhancements

### Planned Features
- [ ] Database integration (Supabase)
- [ ] User authentication
- [ ] Multi-user support
- [ ] Run sharing (public links)
- [ ] Advanced history search
- [ ] Export to PDF
- [ ] Batch processing
- [ ] Webhook notifications

### Scalability Considerations
- Add Redis for session storage
- Implement rate limiting (per user/IP)
- Add caching layer for master script
- Queue long-running requests (BullMQ)
- Horizontal scaling (stateless API)

## Troubleshooting

### Common Issues

**"Missing env var: OPENAI_API_KEY"**
- Solution: Set `OPENAI_API_KEY` in `.env.local`

**"LLM error 401: Unauthorized"**
- Solution: Verify API key is valid

**"Invalid output: must include EXACTLY ONE of..."**
- Solution: Check master script format
- Solution: Increase `max_tokens` if output is truncated

**"Refused: disallowed content detected"**
- Solution: Review INTAKE for forbidden terms
- Solution: Rephrase request if legitimate

### Debug Mode
Enable verbose logging:
```typescript
// app/api/run/route.ts
console.log("Request body:", body);
console.log("LLM response:", result);
```

## License

Proprietary. © 2026 E11EVEN.
