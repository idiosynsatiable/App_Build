# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.1.x   | :white_check_mark: |

## Reporting a Vulnerability

We take security seriously. If you discover a security vulnerability, please report it responsibly:

### How to Report

**Email**: security@a1-blueprint-builder.com

**Include**:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

**Do NOT**:
- Publicly disclose the vulnerability before we've had a chance to fix it
- Exploit the vulnerability beyond what's necessary to demonstrate it

### Response Timeline

- **24 hours**: Acknowledgment of your report
- **7 days**: Initial assessment and severity classification
- **30 days**: Fix deployed (for critical vulnerabilities)
- **90 days**: Public disclosure (coordinated with you)

### Scope

**In Scope**:
- Authentication bypass
- Authorization flaws (entitlement gate bypass)
- SQL injection
- XSS (Cross-Site Scripting)
- CSRF (Cross-Site Request Forgery)
- Webhook signature bypass
- Secrets exposure in client bundle
- RLS policy bypass

**Out of Scope**:
- Social engineering
- Physical attacks
- DDoS attacks
- Issues in third-party dependencies (report to the vendor)
- Issues requiring physical access to user devices

## Security Measures

### Authentication
- Supabase Auth with magic links
- Session cookies (httpOnly, secure, sameSite)
- Middleware refreshes sessions automatically

### Authorization
- Row-Level Security (RLS) on Supabase tables
- Server-side entitlement checks before compilation
- No client-side authorization logic

### Data Protection
- TLS 1.3 for all connections
- Database encryption at rest (Supabase)
- No credit card data stored (Stripe handles payments)
- Secrets stored in environment variables only

### Webhook Security
- Stripe signature verification (HMAC)
- Webhook events processed idempotently
- Failed signature checks logged and rejected

### Input Validation
- Zod schemas for API requests
- Safety scan for forbidden content
- Terminal output validation

### Secrets Management
- Environment variables only (no hardcoded secrets)
- `.env.local` in `.gitignore`
- Separate keys for dev/staging/production

### Monitoring
- Server logs retained for 30 days
- Failed authentication attempts logged
- Webhook signature failures logged
- Rate limiting (platform-level)

## Best Practices for Users

- Use a strong, unique password (if using email/password auth)
- Enable 2FA if available
- Review your subscription in the Customer Portal regularly
- Report suspicious activity immediately
- Keep your browser and OS updated

## Incident Response

In the event of a security incident:

1. **Detection**: Automated monitoring + user reports
2. **Containment**: Isolate affected systems, revoke compromised keys
3. **Eradication**: Fix vulnerability, deploy patch
4. **Recovery**: Restore service, verify integrity
5. **Notification**: Inform affected users within 72 hours (GDPR compliance)
6. **Post-Mortem**: Document incident, update security measures

## Compliance

- **GDPR**: User data rights (access, deletion, portability)
- **PCI DSS**: Stripe handles payment processing (Level 1 certified)
- **SOC 2**: Supabase is SOC 2 Type II certified

## Security Audits

- **Internal**: Quarterly code reviews
- **External**: Annual penetration testing (planned for Q2 2026)
- **Dependency**: Automated scanning via Dependabot

## Contact

**Security Team**: security@a1-blueprint-builder.com

**Bug Bounty**: Not currently available (may be introduced in the future)
