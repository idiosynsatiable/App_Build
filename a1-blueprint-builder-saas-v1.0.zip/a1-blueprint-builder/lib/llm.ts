import { z } from "zod";

export const RunRequestSchema = z.object({
  intake: z.string().min(50, "INTAKE is too short."),
  maxTokens: z.number().int().min(256).max(4000).optional()
});

export type RunRequest = z.infer<typeof RunRequestSchema>;

export type LlmResult = {
  output: string;
  model: string;
};

function env(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env var: ${name}`);
  return v;
}

export async function callLlm(
  systemPrompt: string,
  userPrompt: string,
  maxTokens?: number
): Promise<LlmResult> {
  const apiKey = env("OPENAI_API_KEY");
  const model = env("OPENAI_MODEL");
  const baseUrl = process.env.OPENAI_BASE_URL || "https://api.openai.com/v1";

  const body = {
    model,
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ],
    temperature: 0.2,
    max_tokens: maxTokens ?? 2500
  };

  const r = await fetch(`${baseUrl.replace(/\/$/, "")}/chat/completions`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });

  if (!r.ok) {
    const t = await r.text();
    throw new Error(`LLM error ${r.status}: ${t}`);
  }

  const j = await r.json() as { choices?: Array<{ message?: { content?: string } }> };
  const content = j?.choices?.[0]?.message?.content;
  if (!content || typeof content !== "string") throw new Error("LLM returned no content.");
  return { output: content, model };
}
