export const STRIPE_PLANS = {
  starter: {
    name: "Starter",
    price: 19,
    priceId: process.env.STRIPE_PRICE_ID_STARTER!,
    features: [
      "10 compilations per month",
      "Email support",
      "Community access",
      "Basic templates",
    ],
  },
  pro: {
    name: "Pro",
    price: 49,
    priceId: process.env.STRIPE_PRICE_ID_PRO!,
    features: [
      "100 compilations per month",
      "Priority support",
      "Advanced templates",
      "Custom personas",
      "Export to PDF",
    ],
  },
  team: {
    name: "Team",
    price: 149,
    priceId: process.env.STRIPE_PRICE_ID_TEAM!,
    features: [
      "Unlimited compilations",
      "Dedicated support",
      "API access",
      "Team collaboration",
      "Custom integrations",
      "SLA guarantee",
    ],
  },
} as const;

export type PlanId = keyof typeof STRIPE_PLANS;
