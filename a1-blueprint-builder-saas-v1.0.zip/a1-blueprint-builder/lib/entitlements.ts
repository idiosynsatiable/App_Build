import { createClient } from "@/lib/supabase/server";

export type Tier = "free" | "starter" | "pro" | "team";
export type Status = "active" | "canceled" | "past_due" | "incomplete";

export interface Entitlement {
  user_id: string;
  tier: Tier;
  status: Status;
  stripe_customer_id: string | null;
  stripe_subscription_id: string | null;
  current_period_end: string | null;
  created_at: string;
  updated_at: string;
}

export interface EntitlementFeatures {
  canCompile: boolean;
  maxCompilationsPerMonth: number;
  prioritySupport: boolean;
  apiAccess: boolean;
}

const TIER_FEATURES: Record<Tier, EntitlementFeatures> = {
  free: {
    canCompile: false,
    maxCompilationsPerMonth: 0,
    prioritySupport: false,
    apiAccess: false,
  },
  starter: {
    canCompile: true,
    maxCompilationsPerMonth: 10,
    prioritySupport: false,
    apiAccess: false,
  },
  pro: {
    canCompile: true,
    maxCompilationsPerMonth: 100,
    prioritySupport: true,
    apiAccess: false,
  },
  team: {
    canCompile: true,
    maxCompilationsPerMonth: -1, // unlimited
    prioritySupport: true,
    apiAccess: true,
  },
};

export async function getUserEntitlement(
  userId: string
): Promise<Entitlement | null> {
  const supabase = createClient();

  const { data, error } = await supabase
    .from("entitlements")
    .select("*")
    .eq("user_id", userId)
    .single();

  if (error) {
    console.error("Error fetching entitlement:", error);
    return null;
  }

  return data as Entitlement;
}

export function getFeatures(tier: Tier): EntitlementFeatures {
  return TIER_FEATURES[tier];
}

export async function canUserCompile(userId: string): Promise<boolean> {
  const entitlement = await getUserEntitlement(userId);
  
  if (!entitlement) {
    return false;
  }

  // Check if subscription is active
  if (entitlement.status !== "active") {
    return false;
  }

  // Check if tier allows compilation
  const features = getFeatures(entitlement.tier);
  return features.canCompile;
}

export async function upsertEntitlement(
  userId: string,
  data: Partial<Omit<Entitlement, "user_id" | "created_at" | "updated_at">>
): Promise<Entitlement | null> {
  const supabase = createClient();

  const { data: result, error } = await supabase
    .from("entitlements")
    .upsert({
      user_id: userId,
      ...data,
    })
    .select()
    .single();

  if (error) {
    console.error("Error upserting entitlement:", error);
    return null;
  }

  return result as Entitlement;
}
