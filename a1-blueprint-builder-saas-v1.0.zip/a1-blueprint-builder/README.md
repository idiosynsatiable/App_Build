# A-1 Blueprint Builder (v0.1.0)

A local-first web app that runs the **A-1 ROUTER-PRIME BLUEPRINT BUILDER v1.3** against an LLM to produce either **NEXT FILE BATCH (<=12)** or **FINAL SHIP PACKAGE** (terminal). No infinite loops.

## 1) Setup

```bash
cp .env.example .env.local
# Edit .env.local and set:
# OPENAI_API_KEY=sk-...
# OPENAI_MODEL=gpt-4.1-mini  (or gpt-4.1-nano, gemini-2.5-flash, etc.)
# OPENAI_BASE_URL=https://api.openai.com/v1  (optional, already defaulted)

pnpm install
pnpm dev
# Open http://localhost:3000
```

## 2) Usage

1. Paste a filled **INTAKE** (see master script Section 1).
2. Click **Run**.
3. The system will output **NEXT FILE BATCH** or **FINAL SHIP PACKAGE** (terminal).
4. Download the output as `.md` and save to local history.

## 3) Safety

The runner enforces anti-abuse rules and will refuse disallowed outputs.

## 4) Stack

- **Next.js 14** (App Router) + TypeScript
- **Zod** for input validation
- **OpenAI-compatible API** (configurable via env)
- **localStorage** for run history (no DB required for MVP)

## 5) Architecture

```
app/
  layout.tsx       - Root layout
  page.tsx         - Main UI (intake form + output display)
  globals.css      - Styling
  api/
    run/
      route.ts     - POST /api/run (LLM invocation + validation)
lib/
  llm.ts           - LLM client + Zod schemas
prompts/
  a1_master_script_v1_3.txt - Master script (system prompt)
```

## 6) Deployment

Deploy to **Vercel**, **Netlify**, or any Next.js host:

```bash
pnpm build
pnpm start
```

Set environment variables in the hosting platform dashboard.

## 7) License

Proprietary. © 2026 E11EVEN.
