# Terms of Service

**Last Updated**: January 30, 2026

## 1. Acceptance of Terms

By accessing or using A-1 Blueprint Builder ("Service"), you agree to these Terms of Service ("Terms"). If you disagree, do not use the Service.

## 2. Description of Service

A-1 Blueprint Builder is a SaaS platform that compiles software and hardware blueprints using AI-powered workflows. The Service processes user-provided INTAKE forms and generates structured outputs (NEXT FILE BATCH or FINAL SHIP PACKAGE).

## 3. Account Registration

You must provide accurate and complete information during registration. You are responsible for maintaining the confidentiality of your account credentials. You must notify us immediately of any unauthorized use of your account.

## 4. Acceptable Use

You agree **not** to use the Service to:
- Generate malware, hacking tools, or exploit code
- Create systems for credential theft or stealth exfiltration
- Build illicit command-and-control infrastructure
- Evade terms of service of other platforms
- Abuse accounts or automate account creation
- Generate pornographic or illegal content

**Note**: Legitimate device management systems ("C2") are permitted if authenticated, authorized, logged, permissioned, and revocable.

## 5. Subscription and Billing

### 5.1 Plans
- **Free**: No compilation access (view-only)
- **Starter**: 10 compilations/month ($19/month)
- **Pro**: 100 compilations/month ($49/month)
- **Team**: Unlimited compilations ($149/month)

### 5.2 Payment
- Subscriptions are billed monthly via Stripe
- All fees are in USD and non-refundable
- Prices may change with 30 days notice

### 5.3 Cancellation
- You may cancel anytime via the Customer Portal
- Access continues until the end of the current billing period
- No refunds for partial months

### 5.4 Failed Payments
- If payment fails, your subscription enters "past_due" status
- Compilation access is suspended until payment succeeds
- After 7 days, the subscription is canceled

## 6. Intellectual Property

### 6.1 Your Content
- You retain all rights to your INTAKE and generated outputs
- You grant us a license to process your INTAKE for Service delivery
- We do not claim ownership of your blueprints

### 6.2 Our Content
- The Service, including the master script and UI, is our proprietary property
- You may not reverse-engineer, copy, or redistribute the Service

## 7. Data and Privacy

Your use of the Service is governed by our Privacy Policy. We process your INTAKE using third-party LLM providers (e.g., OpenAI). By using the Service, you consent to this processing.

## 8. Service Availability

We strive for 99.9% uptime but do not guarantee uninterrupted access. We may suspend the Service for maintenance with reasonable notice.

## 9. Limitation of Liability

TO THE MAXIMUM EXTENT PERMITTED BY LAW:
- THE SERVICE IS PROVIDED "AS IS" WITHOUT WARRANTIES
- WE ARE NOT LIABLE FOR INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
- OUR TOTAL LIABILITY IS LIMITED TO THE AMOUNT YOU PAID IN THE PAST 12 MONTHS

## 10. Indemnification

You agree to indemnify us against claims arising from your use of the Service, including violations of these Terms or third-party rights.

## 11. Termination

We may terminate your account if you violate these Terms. Upon termination, your access is revoked immediately. You may delete your account anytime via the Customer Portal.

## 12. Changes to Terms

We may update these Terms with 30 days notice. Continued use after changes constitutes acceptance.

## 13. Governing Law

These Terms are governed by the laws of [Your Jurisdiction]. Disputes will be resolved in [Your Jurisdiction] courts.

## 14. Contact

For questions about these Terms: legal@a1-blueprint-builder.com

For support: support@a1-blueprint-builder.com
