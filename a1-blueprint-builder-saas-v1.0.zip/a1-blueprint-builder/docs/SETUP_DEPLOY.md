# Setup & Deployment Guide — A-1 Blueprint Builder SaaS

This guide walks you through deploying the A-1 Blueprint Builder from scratch to production on Vercel with Supabase and Stripe.

---

## Prerequisites

- GitHub account
- Vercel account (free tier OK)
- Supabase account (free tier OK)
- Stripe account (test mode first)
- Node.js 22+ and pnpm installed locally

---

## Part 1: Supabase Setup

### 1.1 Create Supabase Project

1. Go to [supabase.com](https://supabase.com) and sign in
2. Click "New Project"
3. Choose organization and project name (e.g., "a1-blueprint-builder")
4. Set database password (save it securely)
5. Choose region (closest to your users)
6. Click "Create new project" (takes ~2 minutes)

### 1.2 Run Database Migration

1. In Supabase dashboard, go to **SQL Editor**
2. Click "New query"
3. Copy contents of `supabase/migrations/001_entitlements.sql`
4. Paste into SQL Editor
5. Click "Run" (bottom right)
6. Verify success: Go to **Table Editor** → should see `entitlements` table

### 1.3 Get API Keys

1. Go to **Project Settings** → **API**
2. Copy these values (you'll need them later):
   - **Project URL**: `https://xxx.supabase.co`
   - **anon public key**: `eyJhbGc...`
   - **service_role key**: `eyJhbGc...` (click "Reveal" to see it)

---

## Part 2: Stripe Setup

### 2.1 Create Products

1. Go to [dashboard.stripe.com](https://dashboard.stripe.com) and sign in
2. Make sure you're in **Test mode** (toggle in top right)
3. Go to **Products** → **Add product**

**Product 1: Starter**
- Name: `Starter`
- Description: `10 compilations per month`
- Pricing: `Recurring` → `Monthly` → `$19.00 USD`
- Click "Save product"
- **Copy the Price ID** (starts with `price_`): `price_xxx`

**Product 2: Pro**
- Name: `Pro`
- Description: `100 compilations per month`
- Pricing: `Recurring` → `Monthly` → `$49.00 USD`
- Click "Save product"
- **Copy the Price ID**: `price_yyy`

**Product 3: Team**
- Name: `Team`
- Description: `Unlimited compilations`
- Pricing: `Recurring` → `Monthly` → `$149.00 USD`
- Click "Save product"
- **Copy the Price ID**: `price_zzz`

### 2.2 Enable Customer Portal

1. Go to **Settings** → **Billing** → **Customer portal**
2. Click "Activate test link"
3. Configure settings:
   - **Functionality**: Enable "Cancel subscriptions"
   - **Business information**: Add your company name
4. Click "Save changes"

### 2.3 Get API Keys

1. Go to **Developers** → **API keys**
2. Copy these values:
   - **Publishable key**: `pk_test_...`
   - **Secret key**: `sk_test_...` (click "Reveal")

### 2.4 Create Webhook Endpoint (after Vercel deploy)

**Note**: Do this AFTER deploying to Vercel (Part 4). You'll need your production URL first.

1. Go to **Developers** → **Webhooks**
2. Click "Add endpoint"
3. **Endpoint URL**: `https://your-app.vercel.app/api/webhooks/stripe`
4. **Events to send**:
   - `checkout.session.completed`
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_failed`
5. Click "Add endpoint"
6. **Copy the Signing secret**: `whsec_...`

---

## Part 3: GitHub Setup

### 3.1 Create Repository

```bash
cd /path/to/a1-blueprint-builder
git init
git add .
git commit -m "Initial commit: A-1 Blueprint Builder SaaS"
gh repo create a1-blueprint-builder --private --source=. --remote=origin --push
```

Or via GitHub web:
1. Go to [github.com/new](https://github.com/new)
2. Repository name: `a1-blueprint-builder`
3. Private
4. Do NOT initialize with README
5. Click "Create repository"
6. Follow instructions to push existing code

### 3.2 Verify CI

1. Go to your repo → **Actions** tab
2. Should see CI workflow running
3. Wait for it to complete (green checkmark)

---

## Part 4: Vercel Deployment

### 4.1 Create Vercel Project

1. Go to [vercel.com](https://vercel.com) and sign in
2. Click "Add New..." → "Project"
3. Import your GitHub repository: `a1-blueprint-builder`
4. **Framework Preset**: Next.js (auto-detected)
5. **Root Directory**: `./` (default)
6. **Build Command**: `pnpm build` (default)
7. **Output Directory**: `.next` (default)
8. **DO NOT DEPLOY YET** — Click "Environment Variables" first

### 4.2 Set Environment Variables

Click "Environment Variables" and add these (for **Production** and **Preview**):

**OpenAI / LLM**:
```
OPENAI_API_KEY = sk-...
OPENAI_MODEL = gpt-4.1-mini
OPENAI_BASE_URL = https://api.openai.com/v1
```

**Supabase** (from Part 1.3):
```
NEXT_PUBLIC_SUPABASE_URL = https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = eyJhbGc...
SUPABASE_SERVICE_ROLE_KEY = eyJhbGc...
```

**Stripe** (from Part 2.3):
```
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY = pk_test_...
STRIPE_SECRET_KEY = sk_test_...
STRIPE_PRICE_ID_STARTER = price_xxx
STRIPE_PRICE_ID_PRO = price_yyy
STRIPE_PRICE_ID_TEAM = price_zzz
```

**Application**:
```
APP_URL = https://your-app.vercel.app
```
(You'll update this after first deploy)

### 4.3 Deploy

1. Click "Deploy"
2. Wait for build to complete (~2-3 minutes)
3. Click "Visit" to see your app
4. **Copy the production URL** (e.g., `https://a1-blueprint-builder.vercel.app`)

### 4.4 Update APP_URL

1. Go to Vercel dashboard → Your project → **Settings** → **Environment Variables**
2. Find `APP_URL`
3. Click "Edit" → Update value to your production URL
4. Click "Save"
5. Go to **Deployments** → Click "..." on latest → "Redeploy"

---

## Part 5: Connect Stripe Webhook

Now that you have a production URL, configure the webhook:

1. Go back to Stripe dashboard → **Developers** → **Webhooks**
2. Click "Add endpoint"
3. **Endpoint URL**: `https://your-app.vercel.app/api/webhooks/stripe`
4. **Events to send**: (same as Part 2.4)
5. Click "Add endpoint"
6. **Copy the Signing secret**: `whsec_...`

### 5.1 Add Webhook Secret to Vercel

1. Go to Vercel dashboard → Your project → **Settings** → **Environment Variables**
2. Add new variable:
   ```
   STRIPE_WEBHOOK_SECRET = whsec_...
   ```
3. Click "Save"
4. Go to **Deployments** → Redeploy

---

## Part 6: Smoke Test

### 6.1 Test Signup

1. Visit your production URL
2. Click "Sign Up"
3. Enter email
4. Check email for magic link
5. Click link → Should be signed in

### 6.2 Test Subscription (Test Mode)

1. Click "Upgrade" or "Pricing"
2. Select "Starter" plan
3. Click "Subscribe"
4. Enter test card: `4242 4242 4242 4242`
5. Expiry: Any future date (e.g., `12/34`)
6. CVC: Any 3 digits (e.g., `123`)
7. Click "Subscribe"
8. Should redirect back to app

### 6.3 Test Compilation

1. Paste sample INTAKE:
   ```
   PROJECT_NAME: Test Project
   ONE-LINER: A test application
   TARGET USERS: Developers
   PLATFORMS: web
   MVP FEATURES (<=12):
   - Feature 1
   - Feature 2
   - Feature 3
   NON-GOALS (<=6):
   - Non-goal 1
   DATA SENSITIVITY: low
   MONETIZATION: none
   CONSTRAINTS: none
   EXISTING REPO?: new
   PREFERRED STACK?: Next.js
   EXECUTION_ENV: manus
   BLUEPRINT TARGETS:
   - [x] Pure software-only
   DEFINITION OF DONE:
   - Criterion 1
   - Criterion 2
   - Criterion 3
   ```
2. Click "Run"
3. Should see output (NEXT FILE BATCH or FINAL SHIP PACKAGE)

### 6.4 Test Customer Portal

1. Click "Manage Subscription"
2. Should open Stripe Customer Portal
3. Click "Cancel plan"
4. Confirm cancellation
5. Return to app
6. Try to compile → Should see "Subscription required"

### 6.5 Test Webhook

1. Go to Stripe dashboard → **Developers** → **Webhooks**
2. Click your webhook endpoint
3. Click "Send test webhook"
4. Select `customer.subscription.deleted`
5. Click "Send test webhook"
6. Check Vercel logs: Should see "Subscription canceled for user..."

---

## Part 7: Go Live (Production Mode)

Once testing is complete, switch to production:

### 7.1 Stripe Production Mode

1. Go to Stripe dashboard
2. Toggle to **Live mode** (top right)
3. Repeat Part 2: Create products, get API keys, create webhook
4. Update Vercel env vars with **live** keys:
   - `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY = pk_live_...`
   - `STRIPE_SECRET_KEY = sk_live_...`
   - `STRIPE_WEBHOOK_SECRET = whsec_...` (live webhook)
   - `STRIPE_PRICE_ID_STARTER = price_...` (live)
   - `STRIPE_PRICE_ID_PRO = price_...` (live)
   - `STRIPE_PRICE_ID_TEAM = price_...` (live)
5. Redeploy

### 7.2 Announcement

- Update landing page with "Live" badge
- Announce on social media, Product Hunt, etc.
- Monitor error rates and webhook delivery

---

## Troubleshooting

### Build Fails

**Error**: `Missing env var: OPENAI_API_KEY`
- **Fix**: Add all required env vars in Vercel dashboard

**Error**: TypeScript errors
- **Fix**: Run `pnpm exec tsc --noEmit` locally, fix errors, push

### Webhook Not Working

**Error**: Webhook returns 400 "Invalid signature"
- **Fix**: Verify `STRIPE_WEBHOOK_SECRET` matches Stripe dashboard

**Error**: Entitlement not updated after subscription
- **Fix**: Check Vercel logs for errors, verify Supabase RLS policies

### Compilation Blocked

**Error**: "Subscription required" even after subscribing
- **Fix**: Check `entitlements` table in Supabase → Verify `status='active'` and `tier` is correct

### Auth Not Working

**Error**: "Unauthorized" when trying to compile
- **Fix**: Verify Supabase env vars are correct, check middleware is running

---

## Monitoring

### Vercel Logs

- Go to Vercel dashboard → Your project → **Logs**
- Filter by "Errors" to see failures

### Stripe Webhook Logs

- Go to Stripe dashboard → **Developers** → **Webhooks** → Your endpoint
- Click "View logs" to see delivery status

### Supabase Logs

- Go to Supabase dashboard → **Logs** → **Postgres Logs**
- Check for RLS policy violations

---

## Rollback Plan

If critical issue detected:

1. Go to Vercel dashboard → **Deployments**
2. Find previous working deployment
3. Click "..." → "Promote to Production"
4. Investigate issue in Preview environment
5. Fix and redeploy

---

## Support

- **Technical issues**: Check RUNBOOK.md
- **Security issues**: See SECURITY.md
- **Legal questions**: See docs/TERMS.md and docs/PRIVACY.md

---

**Status**: Ready for deployment  
**Last Updated**: 2026-01-30
