# Exit Criteria — A-1 Blueprint Builder SaaS

**Version**: 1.0  
**Last Updated**: 2026-01-30

## Purpose

This document defines the **hard stop** conditions for shipping the A-1 Blueprint Builder as a production SaaS. All criteria must be satisfied with evidence before FINAL SHIP PACKAGE is emitted.

---

## Release Gates (Binary: PASS/FAIL)

### Gate A — Build

**Criteria**:
1. `pnpm build` succeeds with no errors
2. Application runs locally in production mode
3. Pricing page loads and displays 3 tiers
4. Compile endpoint returns 401 for unauthenticated users

**Evidence**:
- [ ] CI pipeline passes (GitHub Actions)
- [ ] Local build log: `pnpm build` → ✓ Compiled successfully
- [ ] Manual test: `pnpm start` → http://localhost:3000 loads
- [ ] Manual test: POST /api/run without auth → 401

**Status**: ⬜ PENDING

---

### Gate B — Security Baseline

**Criteria**:
1. Entitlement enforced server-side (compile endpoint checks `canUserCompile`)
2. Webhook signature verified (Stripe HMAC check)
3. Secrets not in client bundle (no `STRIPE_SECRET_KEY` in JS)
4. RLS policies enabled on `entitlements` table

**Evidence**:
- [ ] Code review: `app/api/run/route.ts` calls `canUserCompile` before LLM
- [ ] Code review: `app/api/webhooks/stripe/route.ts` verifies signature
- [ ] Build inspection: `grep -r "STRIPE_SECRET_KEY" .next/` → no matches
- [ ] Supabase dashboard: RLS enabled on `entitlements` table

**Status**: ⬜ PENDING

---

### Gate C — Quality (Smoke Flow)

**Criteria**:
Smoke flow executed end-to-end:
1. Browse → Sign up → Subscribe (Starter) → Return → Compile works
2. Manage subscription → Cancel in portal → Compile blocked

**Evidence**:
- [ ] Smoke test log with timestamps and screenshots
- [ ] Free user: Compile → 403 "Subscription required"
- [ ] Starter user: Compile → 200 with output
- [ ] Canceled user: Compile → 403 "Subscription required"

**Status**: ⬜ PENDING

---

## Exit Conditions (Must All Be TRUE)

| # | Condition | Evidence Pointer | Status |
|---|-----------|------------------|--------|
| 1 | All 3 Release Gates PASS | See Gate A/B/C above | ⬜ |
| 2 | Environment variables documented | See `docs/ENV_VARS.md` | ⬜ |
| 3 | Stripe products created in dashboard | See `docs/STRIPE_SETUP.md` | ⬜ |
| 4 | Supabase project configured | See `docs/SUPABASE_SETUP.md` | ⬜ |
| 5 | GitHub repo pushed with CI passing | See GitHub Actions badge | ⬜ |
| 6 | Vercel project created and linked | See `docs/VERCEL_SETUP.md` | ⬜ |
| 7 | Legal docs published | Privacy, Terms, Security in `/docs` | ⬜ |
| 8 | Webhook endpoint configured in Stripe | See `docs/STRIPE_SETUP.md` | ⬜ |
| 9 | Customer Portal enabled in Stripe | See `docs/STRIPE_SETUP.md` | ⬜ |
| 10 | Rollback plan documented | See `docs/ROLLBACK.md` | ⬜ |

---

## Deployment Checklist

- [ ] Supabase project created
- [ ] Run migration: `supabase/migrations/001_entitlements.sql`
- [ ] Stripe account configured (test mode first)
- [ ] Create 3 products in Stripe: Starter, Pro, Team
- [ ] Copy price IDs to environment variables
- [ ] GitHub repo created and pushed
- [ ] Vercel project created and linked to GitHub
- [ ] Environment variables set in Vercel (see `docs/ENV_VARS.md`)
- [ ] Deploy to Vercel Preview
- [ ] Test smoke flow in Preview
- [ ] Deploy to Vercel Production
- [ ] Configure Stripe webhook endpoint (production)
- [ ] Test webhook with Stripe CLI: `stripe trigger checkout.session.completed`
- [ ] Enable Customer Portal in Stripe
- [ ] Test end-to-end: Sign up → Subscribe → Compile → Cancel

---

## Go/No-Go Decision

**Ship Criteria**: All 10 Exit Conditions = ✅

**If ANY condition = ⬜ or ❌**:
- Emit **NEXT FILE BATCH** with specific fixes
- Do NOT emit FINAL SHIP PACKAGE

**If ALL conditions = ✅**:
- Emit **FINAL SHIP PACKAGE**
- Include release tag, deploy steps, rollback plan
- STOP (no further batching)

---

## Post-Launch Monitoring

**Week 1**:
- Monitor error rates (target: <1%)
- Monitor webhook delivery (Stripe dashboard)
- Monitor signup → subscribe conversion
- Respond to support tickets within 24 hours

**Month 1**:
- Review usage patterns
- Optimize performance bottlenecks
- Plan v1.1 features (see `specs/V1_1_BACKLOG.md`)

---

**Status**: ⬜ PENDING  
**Last Verified**: [Date]  
**Verified By**: [Name]
