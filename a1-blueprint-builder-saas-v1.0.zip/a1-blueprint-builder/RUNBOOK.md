# A-1 Blueprint Builder Runbook

## Quick Start Commands

```bash
# Local Development
pnpm install
cp .env.example .env.local
# Edit .env.local with your API key and model
pnpm dev

# Production Build
pnpm build
pnpm start

# Testing
pnpm exec tsc --noEmit  # Type check
pnpm lint               # Lint check
```

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `OPENAI_API_KEY` | Yes | - | OpenAI API key (or compatible provider) |
| `OPENAI_MODEL` | Yes | - | Model name (e.g., `gpt-4.1-mini`, `gemini-2.5-flash`) |
| `OPENAI_BASE_URL` | No | `https://api.openai.com/v1` | API base URL (for OpenRouter, local LLMs, etc.) |

## File Structure

```
a1-blueprint-builder/
├── app/
│   ├── api/
│   │   └── run/
│   │       └── route.ts          # API endpoint for LLM invocation
│   ├── globals.css               # Global styles (dark theme)
│   ├── layout.tsx                # Root layout
│   └── page.tsx                  # Main UI (intake form + output)
├── lib/
│   └── llm.ts                    # LLM client + Zod schemas
├── prompts/
│   └── a1_master_script_v1_3.txt # Master script (system prompt)
├── ARCHITECTURE.md               # System architecture docs
├── DEPLOYMENT.md                 # Deployment guides
├── LAUNCH_CHECKLIST.md           # Pre-launch checklist
├── README.md                     # Project overview
├── .env.example                  # Environment template
├── .gitignore                    # Git ignore rules
├── package.json                  # Dependencies
└── tsconfig.json                 # TypeScript config
```

## API Endpoints

### POST /api/run

**Purpose**: Execute master script against LLM with user-provided INTAKE.

**Request Body**:
```json
{
  "intake": "PROJECT_NAME: ...\nONE-LINER: ...",
  "maxTokens": 2500  // Optional, default 2500, max 4000
}
```

**Success Response** (200):
```json
{
  "output": "...",
  "model": "gpt-4.1-mini",
  "timestamp": "2026-01-29T12:00:00.000Z"
}
```

**Error Responses**:
- **400**: Validation failed (input too short, invalid format)
- **403**: Safety check failed (forbidden content detected)
- **500**: LLM error or invalid output (missing terminal state)

## Safety Rules

The system blocks requests containing these patterns (case-insensitive):

- `malware`
- `hacking`
- `credential theft`
- `stealth exfiltration`
- `illicit command-and-control`
- `tos evasion`
- `account abuse`
- `pornography`

**Note**: Legitimate "C2" (device management) is allowed if properly contextualized.

## Terminal State Validation

Every LLM output MUST contain **exactly one** of:

1. `NEXT FILE BATCH` (indicates more work needed)
2. `FINAL SHIP PACKAGE` (indicates completion)

If both or neither are present, the API returns a 500 error.

## Common Operations

### Update Master Script

1. Edit `prompts/a1_master_script_v1_3.txt`
2. Restart server (or redeploy)
3. Test with sample INTAKE

### Add New Safety Rule

1. Edit `app/api/run/route.ts`
2. Add pattern to `FORBIDDEN` array:
   ```typescript
   const FORBIDDEN = [
     "malware",
     "new-forbidden-term"
   ];
   ```
3. Rebuild and redeploy

### Change LLM Provider

Set `OPENAI_BASE_URL` to provider's endpoint:

```bash
# OpenRouter
OPENAI_BASE_URL=https://openrouter.ai/api/v1

# Local Ollama
OPENAI_BASE_URL=http://localhost:11434/v1

# Azure OpenAI
OPENAI_BASE_URL=https://your-resource.openai.azure.com/openai/deployments/your-deployment
```

### Increase Token Limit

Default: 2500 tokens. Maximum: 4000 tokens.

**Option 1**: Pass in request body:
```json
{
  "intake": "...",
  "maxTokens": 3500
}
```

**Option 2**: Change default in `lib/llm.ts`:
```typescript
max_tokens: maxTokens ?? 3500  // Increase default
```

## Troubleshooting

### Issue: "Missing env var: OPENAI_API_KEY"

**Cause**: Environment variable not set.

**Solution**:
```bash
# Local
echo "OPENAI_API_KEY=sk-..." >> .env.local

# Vercel
vercel env add OPENAI_API_KEY

# Railway
fly secrets set OPENAI_API_KEY=sk-...
```

### Issue: "LLM error 401: Unauthorized"

**Cause**: Invalid API key.

**Solution**:
1. Verify API key is correct
2. Check API key has not expired
3. Verify API key has sufficient credits

### Issue: "Invalid output: must include EXACTLY ONE of..."

**Cause**: LLM output doesn't contain required terminal state marker.

**Solution**:
1. Check if output was truncated (increase `maxTokens`)
2. Verify master script format is correct
3. Review LLM response in server logs
4. Try different model (some models follow instructions better)

### Issue: "Refused: disallowed content detected"

**Cause**: INTAKE contains forbidden pattern.

**Solution**:
1. Review INTAKE for flagged terms
2. Rephrase if legitimate use case
3. If false positive, remove pattern from `FORBIDDEN` array

### Issue: Build fails with TypeScript errors

**Cause**: Type errors in code.

**Solution**:
```bash
# Check errors
pnpm exec tsc --noEmit

# Fix errors in reported files
# Rebuild
pnpm build
```

### Issue: History not persisting

**Cause**: localStorage disabled or cleared.

**Solution**:
1. Check browser console for errors
2. Verify localStorage is enabled
3. Check browser privacy settings
4. Try different browser

### Issue: Download not working

**Cause**: Browser blocking downloads or popup blocker.

**Solution**:
1. Allow popups for the site
2. Check browser download settings
3. Try different browser

## Monitoring

### Key Metrics

**Response Time**:
- Target: < 30s (p95)
- Monitor: Server logs, APM tools

**Error Rate**:
- Target: < 1%
- Monitor: Error tracking (Sentry, etc.)

**LLM API Usage**:
- Track: Requests per day, tokens used, cost
- Monitor: OpenAI dashboard or provider analytics

**Uptime**:
- Target: > 99.9%
- Monitor: Uptime monitoring service

### Log Locations

**Local Development**:
- Console output (terminal running `pnpm dev`)

**Vercel**:
- Dashboard → Project → Logs
- Real-time function logs

**Netlify**:
- Dashboard → Site → Functions → Logs

**Railway**:
- Dashboard → Project → Deployments → Logs

**Docker**:
```bash
docker logs <container-id>
```

### Health Check

**Manual Test**:
1. Visit application URL
2. Paste sample INTAKE
3. Click "Run"
4. Verify output displays
5. Check for errors

**Automated Test**:
```bash
curl -X POST https://your-app.com/api/run \
  -H "Content-Type: application/json" \
  -d '{"intake":"PROJECT_NAME: Test\nONE-LINER: Test app\nTARGET USERS: Developers\nPLATFORMS: web\nMVP FEATURES (<=12):\n1. Feature 1\n2. Feature 2\n3. Feature 3\nNON-GOALS (<=6):\n1. Non-goal 1\nDATA SENSITIVITY: low\nMONETIZATION: none\nCONSTRAINTS: none\nEXISTING REPO?: new\nPREFERRED STACK?: Next.js\nEXECUTION_ENV: manus\nBLUEPRINT TARGETS:\n- Pure software-only\nDEFINITION OF DONE:\n- Feature 1 works\n- Feature 2 works\n- App deploys"}'
```

## Maintenance

### Weekly Tasks

1. Review error logs
2. Check LLM API usage/costs
3. Monitor response times
4. Review safety scan rejections

### Monthly Tasks

1. Update dependencies (`pnpm update`)
2. Review and update master script
3. Analyze usage patterns
4. Plan feature enhancements
5. Security audit

### Quarterly Tasks

1. Major dependency upgrades
2. Performance optimization review
3. Security penetration testing
4. Disaster recovery drill

## Backup & Recovery

### Data to Backup

**User Data**:
- History stored in browser localStorage (client-side only)
- No server-side data to backup for MVP

**Configuration**:
- Environment variables (store securely)
- Master script file
- Custom safety rules

### Recovery Procedure

**Application Failure**:
1. Check server logs for errors
2. Verify environment variables
3. Test LLM API connectivity
4. Rollback to previous deployment if needed

**Data Loss**:
- User history is client-side only (cannot be recovered)
- Advise users to download important outputs

## Security

### Secrets Management

**Never commit**:
- `.env.local`
- API keys
- Credentials

**Use**:
- Environment variables
- Platform secret managers
- `.gitignore` for local secrets

### API Key Rotation

1. Generate new API key in provider dashboard
2. Update environment variable in deployment platform
3. Verify application still works
4. Revoke old API key

### Incident Response

**If API key leaked**:
1. Immediately revoke key in provider dashboard
2. Generate new key
3. Update environment variable
4. Review access logs for abuse
5. Monitor for unusual charges

**If vulnerability discovered**:
1. Assess severity and impact
2. Develop and test fix
3. Deploy fix ASAP
4. Notify users if needed
5. Document incident and lessons learned

## Performance Optimization

### Current Bottlenecks

1. **LLM API latency**: 10-30s per request (external dependency)
2. **Token limits**: Max 4000 tokens per request
3. **No caching**: Every request hits LLM

### Optimization Strategies

**Short-term**:
- Use faster models (e.g., `gpt-4.1-nano` vs `gpt-4.1-mini`)
- Reduce `max_tokens` if outputs are consistently shorter
- Implement request timeout (prevent hanging)

**Long-term**:
- Add Redis caching for identical INTAKEs
- Implement streaming responses (SSE)
- Queue long requests (BullMQ)
- Add rate limiting per user/IP

## Scaling

### Current Limits

- **Concurrent requests**: Limited by platform (Vercel: 1000/min, Railway: depends on plan)
- **Request timeout**: 30s (default)
- **Storage**: None (localStorage only)

### Scaling Strategy

**Phase 1** (0-100 users):
- Current architecture sufficient
- Monitor response times and error rates

**Phase 2** (100-1000 users):
- Add rate limiting (per IP)
- Implement request queuing
- Add error tracking (Sentry)

**Phase 3** (1000+ users):
- Add database (Supabase) for history
- Implement user authentication
- Add caching layer (Redis)
- Horizontal scaling (multiple instances)

## Support

### User Support

**Common Questions**:

Q: How long does a run take?
A: 10-30 seconds depending on INTAKE complexity and model.

Q: Can I save my history?
A: Yes, history is saved in your browser's localStorage (up to 20 runs).

Q: What models are supported?
A: Any OpenAI-compatible model (set via `OPENAI_MODEL` env var).

Q: Can I use my own LLM?
A: Yes, set `OPENAI_BASE_URL` to your LLM's API endpoint.

### Technical Support

**Contact**: [Your support email]

**Include in support request**:
- Error message (if any)
- INTAKE used (if not sensitive)
- Browser and OS version
- Timestamp of issue
- Steps to reproduce

## Changelog

### v0.1.0 (2026-01-29)
- Initial release
- Next.js 14 + TypeScript
- OpenAI-compatible LLM integration
- Anti-cyclical enforcement
- Safety checks
- localStorage history
- Download as .md

---

**Last Updated**: 2026-01-29
**Maintained By**: E11EVEN
