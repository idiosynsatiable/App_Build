# Entitlements Specification

## Tier Matrix

| Feature | Free | Starter | Pro | Team |
|---------|------|---------|-----|------|
| **Compilations/Month** | 0 | 10 | 100 | Unlimited |
| **Email Support** | ❌ | ✅ | ✅ | ✅ |
| **Priority Support** | ❌ | ❌ | ✅ | ✅ |
| **Community Access** | ✅ | ✅ | ✅ | ✅ |
| **Basic Templates** | ✅ | ✅ | ✅ | ✅ |
| **Advanced Templates** | ❌ | ❌ | ✅ | ✅ |
| **Custom Personas** | ❌ | ❌ | ✅ | ✅ |
| **Export to PDF** | ❌ | ❌ | ✅ | ✅ |
| **API Access** | ❌ | ❌ | ❌ | ✅ |
| **Team Collaboration** | ❌ | ❌ | ❌ | ✅ |
| **Custom Integrations** | ❌ | ❌ | ❌ | ✅ |
| **SLA Guarantee** | ❌ | ❌ | ❌ | ✅ |
| **Price (USD/month)** | $0 | $19 | $49 | $149 |

## Enforcement Points

### 1. Compilation Gate (Server-Side)

**Location**: `app/api/run/route.ts`

**Logic**:
```typescript
const canCompile = await canUserCompile(user.id);
if (!canCompile) {
  return 403 "Subscription required"
}
```

**Checks**:
- User is authenticated
- User has active subscription (status = 'active')
- Tier allows compilation (starter/pro/team)

### 2. UI Gate (Client-Side)

**Location**: `app/page.tsx`

**Logic**:
- If not entitled: Show pricing page
- If entitled: Show compile form

**Note**: This is UX only. Server-side gate is the source of truth.

### 3. Rate Limiting (Future)

**Location**: `app/api/run/route.ts`

**Logic**:
- Track compilations per user per month
- Reject if limit exceeded (except Team tier)

**Implementation**: Add `compilations_used` column to `entitlements` table.

## Subscription Lifecycle

### 1. Sign Up
- User creates account (Supabase Auth)
- Trigger: `on_auth_user_created` → Insert `entitlements` row with `tier='free'`, `status='active'`

### 2. Subscribe
- User clicks "Upgrade" → Stripe Checkout
- Webhook: `checkout.session.completed` → Upsert `entitlements` with `tier`, `stripe_customer_id`, `stripe_subscription_id`

### 3. Active Subscription
- User can compile (if tier allows)
- Webhook: `customer.subscription.updated` → Update `tier`, `status`, `current_period_end`

### 4. Payment Failed
- Webhook: `invoice.payment_failed` → Set `status='past_due'`
- User cannot compile until payment succeeds

### 5. Cancel
- User clicks "Cancel" in Customer Portal
- Webhook: `customer.subscription.deleted` → Set `tier='free'`, `status='canceled'`

### 6. Reactivate
- User clicks "Upgrade" again → Stripe Checkout
- Webhook: `checkout.session.completed` → Upsert `entitlements` with new subscription

## Database Schema

```sql
CREATE TABLE public.entitlements (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  tier TEXT NOT NULL DEFAULT 'free' CHECK (tier IN ('free', 'starter', 'pro', 'team')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'canceled', 'past_due', 'incomplete')),
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  current_period_end TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

## Stripe Price IDs

**Environment Variables** (set in Vercel):
```
STRIPE_PRICE_ID_STARTER=price_xxx
STRIPE_PRICE_ID_PRO=price_yyy
STRIPE_PRICE_ID_TEAM=price_zzz
```

**Mapping** (in `lib/stripe/config.ts`):
```typescript
const PRICE_ID_TO_TIER = {
  [process.env.STRIPE_PRICE_ID_STARTER!]: "starter",
  [process.env.STRIPE_PRICE_ID_PRO!]: "pro",
  [process.env.STRIPE_PRICE_ID_TEAM!]: "team",
};
```

## Testing Checklist

- [ ] Free user cannot compile (403)
- [ ] Starter user can compile (200)
- [ ] Pro user can compile (200)
- [ ] Team user can compile (200)
- [ ] Canceled user cannot compile (403)
- [ ] Past_due user cannot compile (403)
- [ ] Webhook creates entitlement on checkout
- [ ] Webhook updates entitlement on subscription change
- [ ] Webhook sets tier='free' on cancellation
- [ ] Customer Portal allows cancel/reactivate

## Future Enhancements

- Usage tracking (compilations per month)
- Rate limiting per tier
- Team member management (Team tier)
- API keys (Team tier)
- Custom persona library (Pro/Team)
- PDF export (Pro/Team)
