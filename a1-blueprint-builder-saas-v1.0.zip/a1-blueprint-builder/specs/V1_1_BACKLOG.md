# V1.1 Backlog — A-1 Blueprint Builder

## Planned Features (Priority Order)

### 1. Usage Tracking & Rate Limiting
**Why**: Enforce compilation limits per tier (Starter: 10/month, Pro: 100/month)
**Effort**: Medium
**Impact**: High (prevents abuse, enforces pricing tiers)

### 2. Pricing Page UI
**Why**: Currently no dedicated pricing page, users must discover plans manually
**Effort**: Small
**Impact**: High (improves conversion)

### 3. User Dashboard
**Why**: Show current tier, usage stats, subscription status
**Effort**: Medium
**Impact**: Medium (improves UX)

### 4. Email Notifications
**Why**: Notify users of subscription events (payment failed, canceled, approaching limit)
**Effort**: Medium
**Impact**: Medium (reduces churn)

### 5. PDF Export
**Why**: Pro/Team users want professional-looking blueprint PDFs
**Effort**: Large
**Impact**: Medium (premium feature)

### 6. Custom Personas
**Why**: Pro/Team users want to define their own personas
**Effort**: Large
**Impact**: Medium (premium feature)

### 7. Team Collaboration
**Why**: Team tier needs multi-user workspaces
**Effort**: Large
**Impact**: High (enables Team tier value prop)

### 8. API Access
**Why**: Team tier needs programmatic access
**Effort**: Large
**Impact**: Medium (enables integrations)

### 9. Advanced Templates
**Why**: Pro/Team users want pre-built INTAKE templates
**Effort**: Medium
**Impact**: Medium (reduces friction)

### 10. Analytics Dashboard
**Why**: Track user behavior, conversion funnels, churn
**Effort**: Medium
**Impact**: Low (internal tool)

---

## Technical Debt

- Add automated tests (Jest + React Testing Library)
- Add E2E tests (Playwright)
- Implement proper error boundaries
- Add request rate limiting (per IP/user)
- Add Redis caching for identical INTAKEs
- Implement streaming responses (SSE)
- Add Sentry for error tracking
- Add PostHog for product analytics

---

## Security Enhancements

- Add 2FA support
- Implement CAPTCHA on signup
- Add webhook replay attack prevention
- Implement audit logs for sensitive actions
- Add IP-based rate limiting
- Implement anomaly detection for abuse

---

## Performance Optimizations

- Add CDN for static assets
- Implement service worker for offline support
- Add optimistic UI updates
- Lazy load heavy components
- Implement virtual scrolling for history
- Add database query optimization

---

## UX Improvements

- Add onboarding flow for new users
- Implement keyboard shortcuts
- Add dark/light mode toggle (currently dark-only)
- Improve mobile responsiveness
- Add loading skeletons
- Implement toast notifications
- Add inline help/tooltips

---

**Last Updated**: 2026-01-30
