import "./globals.css";

export const metadata = {
  title: "A-1 Blueprint Builder",
  description: "Router-Prime + Personas + Integrator runner (anti-cyclical)"
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
