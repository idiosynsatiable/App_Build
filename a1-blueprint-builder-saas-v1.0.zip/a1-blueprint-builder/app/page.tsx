"use client";

import { useState, useEffect } from "react";

type RunResult = {
  output: string;
  model: string;
  timestamp: string;
  intake: string;
};

type HistoryItem = RunResult & {
  id: string;
};

export default function Home() {
  const [intake, setIntake] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<RunResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);

  // Load history from localStorage
  useEffect(() => {
    const stored = localStorage.getItem("a1-history");
    if (stored) {
      try {
        setHistory(JSON.parse(stored));
      } catch (e) {
        console.error("Failed to parse history:", e);
      }
    }
  }, []);

  // Save to history
  const saveToHistory = (r: RunResult) => {
    const item: HistoryItem = {
      ...r,
      id: Date.now().toString()
    };
    const newHistory = [item, ...history].slice(0, 20); // Keep last 20
    setHistory(newHistory);
    localStorage.setItem("a1-history", JSON.stringify(newHistory));
  };

  const handleRun = async () => {
    if (!intake.trim()) {
      setError("INTAKE cannot be empty.");
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const res = await fetch("/api/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ intake })
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Request failed");
        return;
      }

      const runResult: RunResult = {
        output: data.output,
        model: data.model,
        timestamp: data.timestamp,
        intake
      };

      setResult(runResult);
      saveToHistory(runResult);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : "Network error";
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    if (!result) return;
    const blob = new Blob([result.output], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `a1-output-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const loadFromHistory = (item: HistoryItem) => {
    setIntake(item.intake);
    setResult(item);
    setError(null);
  };

  const clearHistory = () => {
    if (confirm("Clear all history?")) {
      setHistory([]);
      localStorage.removeItem("a1-history");
    }
  };

  return (
    <div className="container">
      <div className="row" style={{ justifyContent: "space-between", marginBottom: 14 }}>
        <div>
          <div className="h1">A-1 Blueprint Builder v1.3</div>
          <div className="small">
            Paste INTAKE → Run → Get NEXT FILE BATCH or FINAL SHIP PACKAGE (terminal)
          </div>
        </div>
        <div className="badge">Anti-abuse enforced</div>
      </div>

      <div className="card">
        <div className="h2">INTAKE</div>
        <textarea
          className="ta"
          placeholder="Paste your filled INTAKE here (Section 1 from master script)..."
          value={intake}
          onChange={(e) => setIntake(e.target.value)}
          disabled={loading}
        />
        <div className="row" style={{ marginTop: 12 }}>
          <button className="btn" onClick={handleRun} disabled={loading}>
            {loading ? "Running..." : "Run"}
          </button>
          <button className="btn secondary" onClick={() => setIntake("")} disabled={loading}>
            Clear
          </button>
        </div>
      </div>

      {error && (
        <div className="card">
          <div className="h2 err">Error</div>
          <pre className="err">{error}</pre>
        </div>
      )}

      {result && (
        <div className="card">
          <div className="row" style={{ justifyContent: "space-between", marginBottom: 10 }}>
            <div className="h2 ok">Output</div>
            <button className="btn secondary" onClick={handleDownload}>
              Download .md
            </button>
          </div>
          <div className="kv">
            <span className="small">Model</span>
            <span className="badge">{result.model}</span>
          </div>
          <div className="kv">
            <span className="small">Timestamp</span>
            <span className="badge">{new Date(result.timestamp).toLocaleString()}</span>
          </div>
          <pre style={{ marginTop: 12, maxHeight: 600, overflowY: "auto" }}>
            {result.output}
          </pre>
        </div>
      )}

      {history.length > 0 && (
        <div className="card">
          <div className="row" style={{ justifyContent: "space-between", marginBottom: 10 }}>
            <div className="h2">History ({history.length})</div>
            <button className="btn secondary" onClick={clearHistory}>
              Clear History
            </button>
          </div>
          {history.map((item) => (
            <div key={item.id} className="kv" style={{ cursor: "pointer" }} onClick={() => loadFromHistory(item)}>
              <span className="small">{new Date(item.timestamp).toLocaleString()}</span>
              <span className="badge">{item.model}</span>
            </div>
          ))}
          <div className="small" style={{ marginTop: 8, opacity: 0.7 }}>
            Click any item to reload
          </div>
        </div>
      )}

      <div className="small" style={{ marginTop: 18, opacity: 0.85 }}>
        Safety: Refuses malware/hacking/illicit C2. &quot;C2&quot; is device-management only.
      </div>
    </div>
  );
}
