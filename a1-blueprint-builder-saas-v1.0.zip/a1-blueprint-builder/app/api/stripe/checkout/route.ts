import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createCheckoutSession } from "@/lib/stripe/server";
import { STRIPE_PLANS, type PlanId } from "@/lib/stripe/config";

export async function POST(req: Request) {
  try {
    const supabase = createClient();
    const { data: { user }, error: authError } = await supabase.auth.getUser();

    if (authError || !user) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const { planId } = await req.json();

    if (!planId || !(planId in STRIPE_PLANS)) {
      return NextResponse.json(
        { error: "Invalid plan" },
        { status: 400 }
      );
    }

    const plan = STRIPE_PLANS[planId as PlanId];
    const appUrl = process.env.APP_URL || "http://localhost:3000";

    const session = await createCheckoutSession({
      priceId: plan.priceId,
      userId: user.id,
      userEmail: user.email!,
      successUrl: `${appUrl}/?success=true`,
      cancelUrl: `${appUrl}/pricing?canceled=true`,
    });

    return NextResponse.json({ url: session.url });
  } catch (err) {
    console.error("Checkout error:", err);
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json(
      { error: message },
      { status: 500 }
    );
  }
}
