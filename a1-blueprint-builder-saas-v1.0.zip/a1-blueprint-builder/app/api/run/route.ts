import { NextResponse } from "next/server";
import fs from "node:fs";
import path from "node:path";
import { RunRequestSchema } from "@/lib/llm";
import { callLlm } from "@/lib/llm";
import { createClient } from "@/lib/supabase/server";
import { canUserCompile } from "@/lib/entitlements";

const FORBIDDEN = [
  "malware",
  "hacking",
  "credential theft",
  "stealth exfiltration",
  "illicit command-and-control",
  "tos evasion",
  "account abuse",
  "pornography"
];

function basicSafetyScan(text: string): string | null {
  const t = text.toLowerCase();
  for (const f of FORBIDDEN) {
    if (t.includes(f)) return `Refused: disallowed content detected ("${f}").`;
  }
  return null;
}

function mustBeTerminalOrBatch(output: string): string | null {
  const hasBatch = output.includes("NEXT FILE BATCH");
  const hasFinal = output.includes("FINAL SHIP PACKAGE");
  if ((hasBatch && hasFinal) || (!hasBatch && !hasFinal)) {
    return "Invalid output: must include EXACTLY ONE of NEXT FILE BATCH or FINAL SHIP PACKAGE.";
  }
  return null;
}

export async function POST(req: Request) {
  try {
    // Check authentication
    const supabase = createClient();
    const { data: { user }, error: authError } = await supabase.auth.getUser();

    if (authError || !user) {
      return NextResponse.json(
        { error: "Unauthorized. Please sign in." },
        { status: 401 }
      );
    }

    // Check entitlement
    const canCompile = await canUserCompile(user.id);
    if (!canCompile) {
      return NextResponse.json(
        { error: "Subscription required. Please upgrade to compile blueprints." },
        { status: 403 }
      );
    }

    const body = await req.json();
    const parsed = RunRequestSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed", details: parsed.error.format() },
        { status: 400 }
      );
    }

    const { intake, maxTokens } = parsed.data;

    // Safety scan
    const safetyErr = basicSafetyScan(intake);
    if (safetyErr) {
      return NextResponse.json({ error: safetyErr }, { status: 403 });
    }

    // Load master script
    const scriptPath = path.join(process.cwd(), "prompts", "a1_master_script_v1_3.txt");
    const systemPrompt = fs.readFileSync(scriptPath, "utf-8");

    // Call LLM
    const result = await callLlm(systemPrompt, intake, maxTokens);

    // Validate terminal output
    const termErr = mustBeTerminalOrBatch(result.output);
    if (termErr) {
      return NextResponse.json({ error: termErr, raw: result.output }, { status: 500 });
    }

    return NextResponse.json({
      output: result.output,
      model: result.model,
      timestamp: new Date().toISOString()
    });
  } catch (err: unknown) {
    console.error("API error:", err);
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json(
      { error: message },
      { status: 500 }
    );
  }
}
