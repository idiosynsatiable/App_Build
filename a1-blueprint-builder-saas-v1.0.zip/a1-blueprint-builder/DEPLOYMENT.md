# Deployment Guide

## Prerequisites

1. **Environment Variables** (required):
   - `OPENAI_API_KEY`: Your OpenAI API key
   - `OPENAI_MODEL`: Model to use (e.g., `gpt-4.1-mini`, `gpt-4.1-nano`, `gemini-2.5-flash`)
   - `OPENAI_BASE_URL` (optional): Defaults to `https://api.openai.com/v1`

## Local Development

```bash
# 1. Install dependencies
pnpm install

# 2. Configure environment
cp .env.example .env.local
# Edit .env.local and set your API key and model

# 3. Run development server
pnpm dev

# 4. Open browser
# Navigate to http://localhost:3000
```

## Production Build

```bash
# Build for production
pnpm build

# Start production server
pnpm start
```

## Deploy to Vercel

### Option 1: Vercel CLI

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
cd a1-blueprint-builder
vercel

# Set environment variables
vercel env add OPENAI_API_KEY
vercel env add OPENAI_MODEL
vercel env add OPENAI_BASE_URL  # optional

# Deploy to production
vercel --prod
```

### Option 2: Vercel Dashboard

1. Push code to GitHub
2. Import project in [Vercel Dashboard](https://vercel.com/new)
3. Set environment variables:
   - `OPENAI_API_KEY`
   - `OPENAI_MODEL`
   - `OPENAI_BASE_URL` (optional)
4. Deploy

## Deploy to Netlify

```bash
# Build command
pnpm build

# Publish directory
.next

# Set environment variables in Netlify dashboard:
# - OPENAI_API_KEY
# - OPENAI_MODEL
# - OPENAI_BASE_URL (optional)
```

## Deploy to Railway

1. Create new project in [Railway](https://railway.app)
2. Connect GitHub repository
3. Set environment variables:
   - `OPENAI_API_KEY`
   - `OPENAI_MODEL`
   - `OPENAI_BASE_URL` (optional)
4. Deploy

## Deploy to Fly.io

```bash
# Install flyctl
curl -L https://fly.io/install.sh | sh

# Launch app
fly launch

# Set secrets
fly secrets set OPENAI_API_KEY=sk-...
fly secrets set OPENAI_MODEL=gpt-4.1-mini
fly secrets set OPENAI_BASE_URL=https://api.openai.com/v1

# Deploy
fly deploy
```

## Docker Deployment

```dockerfile
# Dockerfile
FROM node:22-alpine AS base

# Install dependencies only when needed
FROM base AS deps
RUN apk add --no-cache libc6-compat
WORKDIR /app
COPY package.json pnpm-lock.yaml* ./
RUN corepack enable pnpm && pnpm i --frozen-lockfile

# Rebuild the source code only when needed
FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN corepack enable pnpm && pnpm build

# Production image
FROM base AS runner
WORKDIR /app
ENV NODE_ENV production
RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs
COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static
USER nextjs
EXPOSE 3000
ENV PORT 3000
CMD ["node", "server.js"]
```

```bash
# Build
docker build -t a1-blueprint-builder .

# Run
docker run -p 3000:3000 \
  -e OPENAI_API_KEY=sk-... \
  -e OPENAI_MODEL=gpt-4.1-mini \
  a1-blueprint-builder
```

## Security Checklist

- [ ] Environment variables set (never commit secrets)
- [ ] HTTPS enabled (automatic on Vercel/Netlify)
- [ ] Rate limiting configured (if needed)
- [ ] CORS configured (if needed)
- [ ] Error logging configured (Sentry, etc.)

## Monitoring

- Check `/api/run` endpoint health
- Monitor LLM API usage and costs
- Track error rates in logs
- Set up alerts for API failures

## Troubleshooting

### Build Fails

- Verify all dependencies are installed
- Check TypeScript errors: `pnpm exec tsc --noEmit`
- Check ESLint: `pnpm lint`

### API Errors

- Verify `OPENAI_API_KEY` is set correctly
- Verify `OPENAI_MODEL` is valid
- Check API quota/limits
- Check network connectivity to OpenAI API

### Runtime Errors

- Check browser console for client-side errors
- Check server logs for API route errors
- Verify environment variables are loaded
