-- Create secrets table for admin configuration
CREATE TABLE IF NOT EXISTS public.secrets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key_name TEXT NOT NULL UNIQUE,
  key_value TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.secrets ENABLE ROW LEVEL SECURITY;

-- Policy: Only service_role can manage secrets (admin-only)
CREATE POLICY "Service role can manage secrets"
  ON public.secrets
  FOR ALL
  USING (auth.jwt()->>'role' = 'service_role');

-- Policy: Users cannot read secrets (even their own)
-- This ensures keys are only accessible via server-side service_role calls

-- Add admin role check to entitlements or a new profiles table if needed
-- For now, we'll use a specific admin user ID or service_role for the dashboard
