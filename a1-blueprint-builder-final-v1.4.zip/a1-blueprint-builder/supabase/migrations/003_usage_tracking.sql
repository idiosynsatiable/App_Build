-- Add usage tracking columns to entitlements
ALTER TABLE public.entitlements 
ADD COLUMN IF NOT EXISTS compilations_used INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS last_reset_at TIMESTAMPTZ DEFAULT NOW();

-- Function to reset usage monthly (can be called via cron or on first request of month)
CREATE OR REPLACE FUNCTION public.reset_monthly_usage(target_user_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE public.entitlements
  SET compilations_used = 0,
      last_reset_at = NOW()
  WHERE user_id = target_user_id
  AND last_reset_at < NOW() - INTERVAL '1 month';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to increment compilation usage
CREATE OR REPLACE FUNCTION public.increment_compilation_usage(target_user_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE public.entitlements
  SET compilations_used = compilations_used + 1,
      updated_at = NOW()
  WHERE user_id = target_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
