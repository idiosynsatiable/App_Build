import { createClient } from "@supabase/supabase-js";

// Use service role key for secrets management (server-side only)
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

const supabaseAdmin = (supabaseUrl && supabaseServiceKey) 
  ? createClient(supabaseUrl, supabaseServiceKey)
  : null;

export async function getSecret(name: string): Promise<string | null> {
  // Check environment variable first
  const envValue = process.env[name];
  if (envValue) return envValue;

  if (!supabaseAdmin) return null;

  // Fallback to database secrets
  const { data, error } = await supabaseAdmin
    .from("secrets")
    .select("key_value")
    .eq("key_name", name)
    .single();

  if (error || !data) return null;
  return data.key_value;
}

export async function setSecret(name: string, value: string, description?: string) {
  if (!supabaseAdmin) throw new Error("Supabase admin client not initialized");
  const { error } = await supabaseAdmin
    .from("secrets")
    .upsert({
      key_name: name,
      key_value: value,
      description,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'key_name' });

  if (error) throw error;
}

export async function listSecrets() {
  if (!supabaseAdmin) return [];
  const { data, error } = await supabaseAdmin
    .from("secrets")
    .select("key_name, description, updated_at");

  if (error) throw error;
  return data;
}

export async function deleteSecret(name: string) {
  if (!supabaseAdmin) throw new Error("Supabase admin client not initialized");
  const { error } = await supabaseAdmin
    .from("secrets")
    .delete()
    .eq("key_name", name);

  if (error) throw error;
}
