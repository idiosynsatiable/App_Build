export const STRIPE_PLANS = {
  starter: {
    name: "Starter",
    price: 19,
    priceId: process.env.STRIPE_PRICE_ID_STARTER!,
    features: [
      "10 compilations per month",
      "Email support",
      "Basic templates",
    ],
  },
  pro: {
    name: "Pro",
    price: 49,
    priceId: process.env.STRIPE_PRICE_ID_PRO!,
    features: [
      "100 compilations per month",
      "Priority support",
      "Advanced templates",
    ],
  },
  master: {
    name: "Master",
    price: 99,
    priceId: process.env.STRIPE_PRICE_ID_MASTER!,
    features: [
      "500 compilations per month",
      "1-on-1 onboarding",
      "Custom personas",
    ],
  },
  team: {
    name: "Team",
    price: 149,
    priceId: process.env.STRIPE_PRICE_ID_TEAM!,
    features: [
      "Unlimited compilations",
      "API access",
      "Team collaboration",
    ],
  },
  annual: {
    name: "Annual",
    price: 999,
    priceId: process.env.STRIPE_PRICE_ID_ANNUAL!,
    features: [
      "All Team features",
      "2 months free",
      "Priority SLA",
    ],
  },
  three_year: {
    name: "3-Year",
    price: 2999,
    priceId: process.env.STRIPE_PRICE_ID_3YR!,
    features: [
      "Extended enterprise access",
      "Dedicated account manager",
      "Early access to beta",
    ],
  },
} as const;

export type PlanId = keyof typeof STRIPE_PLANS;
