# A-1 Blueprint Builder — Landing Page Export

This document contains the full HTML and CSS for the high-converting landing page at `/landing`.

## HTML Structure

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A-1 Blueprint Builder — Build Enterprise Blueprints In Seconds</title>
    <style>
        :root { color-scheme: dark; }
        html, body { 
            margin: 0; 
            padding: 0; 
            background: #0b0d10; 
            color: #e7edf5; 
            font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial; 
        }
        .container { max-width: 1100px; margin: 0 auto; padding: 24px; }
        .row { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
        .card { border: 1px solid #1b2430; background: #0f141b; border-radius: 16px; padding: 16px; }
        .h1 { font-size: 26px; margin: 0 0 10px; font-weight: 800; }
        .h2 { font-size: 16px; margin: 14px 0 8px; font-weight: 700; }
        .small { font-size: 12px; color: #9fb0c3; }
        .btn { 
            background: #1d4ed8; 
            border: 0; 
            color: white; 
            padding: 10px 12px; 
            border-radius: 12px; 
            cursor: pointer; 
            font-weight: 700; 
            text-decoration: none;
            display: inline-block;
        }
        .btn.secondary { background: #111827; border: 1px solid #1b2430; }
        .badge { display: inline-block; padding: 4px 8px; border-radius: 999px; border: 1px solid #1b2430; background: #0b0d10; font-size: 12px; }
        .ok { color: #bbf7d0; }

        /* Landing Specific */
        .hero { text-align: center; padding: 80px 24px; }
        .hero-title { font-size: 56px; font-weight: 900; lineHeight: 1.1; margin-bottom: 24px; }
        .hero-accent { color: #1d4ed8; }
        .hero-subtitle { font-size: 18px; color: #9fb0c3; max-width: 600px; margin: 0 auto 40px; line-height: 1.6; }
        .features-grid { margin-top: 80px; display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 30px; }
    </style>
</head>
<body>
    <div class="container hero">
        <div class="badge ok" style="margin-bottom: 20px;">v1.2 Production Ready</div>
        <h1 class="hero-title">
            Build Enterprise Blueprints <br />
            <span class="hero-accent">In Seconds.</span>
        </h1>
        <p class="hero-subtitle">
            The A-1 Router-Prime Blueprint Builder automates the transition from intake to production-ready specs. 
            Anti-cyclical, terminal, and production-grade.
        </p>
        
        <div class="row" style="justify-content: center; gap: 16px;">
            <a href="/auth/signup" class="btn" style="padding: 14px 28px; font-size: 16px;">
                Get Started Free
            </a>
            <a href="/pricing" class="btn secondary" style="padding: 14px 28px; font-size: 16px;">
                View Pricing
            </a>
        </div>

        <div class="features-grid">
            <div class="card">
                <h3 class="h2">Anti-Cyclical</h3>
                <p class="small">Guaranteed to end in NEXT FILE BATCH or FINAL SHIP PACKAGE. No infinite loops.</p>
            </div>
            <div class="card">
                <h3 class="h2">Enterprise Ready</h3>
                <p class="small">Built-in safety scans, Zod validation, and structured output enforcement.</p>
            </div>
            <div class="card">
                <h3 class="h2">Local-First</h3>
                <p class="small">Your history stays in your browser. Privacy by design, performance by default.</p>
            </div>
        </div>
    </div>
</body>
</html>
```
