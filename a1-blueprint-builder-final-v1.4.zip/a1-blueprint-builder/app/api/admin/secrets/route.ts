import { NextResponse } from "next/server";
export const dynamic = "force-dynamic";
import { createClient } from "@/lib/supabase/server";
import { listSecrets, setSecret, deleteSecret } from "@/lib/secrets";

// Simple admin check - in production, use a proper role-based system
async function isAdmin(userId: string) {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("entitlements")
    .select("tier")
    .eq("user_id", userId)
    .single();
  
  return !error && data?.tier === "team"; // Only 'team' tier can access admin for now
}

export async function GET() {
  try {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user || !(await isAdmin(user.id))) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const secrets = await listSecrets();
    return NextResponse.json({ secrets });
  } catch (error) {
    return NextResponse.json({ error: "Failed to list secrets" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user || !(await isAdmin(user.id))) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { name, value, description } = await req.json();
    if (!name || !value) {
      return NextResponse.json({ error: "Name and value required" }, { status: 400 });
    }

    await setSecret(name, value, description);
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: "Failed to save secret" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user || !(await isAdmin(user.id))) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { name } = await req.json();
    await deleteSecret(name);
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: "Failed to delete secret" }, { status: 500 });
  }
}
