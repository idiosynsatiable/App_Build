import { NextResponse } from "next/server";
import { headers } from "next/headers";
import Stripe from "stripe";
import { stripe } from "@/lib/stripe/server";
import { upsertEntitlement } from "@/lib/entitlements";
import type { Tier } from "@/lib/entitlements";

const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET!;

// Map Stripe price IDs to tiers
const PRICE_ID_TO_TIER: Record<string, Tier> = {
  [process.env.STRIPE_PRICE_ID_STARTER!]: "starter",
  [process.env.STRIPE_PRICE_ID_PRO!]: "pro",
  [process.env.STRIPE_PRICE_ID_MASTER!]: "master",
  [process.env.STRIPE_PRICE_ID_TEAM!]: "team",
  [process.env.STRIPE_PRICE_ID_ANNUAL!]: "team", // Annual maps to team features
  [process.env.STRIPE_PRICE_ID_3YR!]: "team",    // 3-Year maps to team features
};

export async function POST(req: Request) {
  const body = await req.text();
  const signature = headers().get("stripe-signature");

  if (!signature) {
    return NextResponse.json(
      { error: "Missing stripe-signature header" },
      { status: 400 }
    );
  }

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error("Webhook signature verification failed:", err);
    return NextResponse.json(
      { error: "Invalid signature" },
      { status: 400 }
    );
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        await handleCheckoutCompleted(session);
        break;
      }

      case "customer.subscription.created":
      case "customer.subscription.updated": {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionUpdate(subscription);
        break;
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionDeleted(subscription);
        break;
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice;
        await handlePaymentFailed(invoice);
        break;
      }

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return NextResponse.json({ received: true });
  } catch (err) {
    console.error("Webhook handler error:", err);
    return NextResponse.json(
      { error: "Webhook handler failed" },
      { status: 500 }
    );
  }
}

async function handleCheckoutCompleted(session: Stripe.Checkout.Session) {
  const userId = session.metadata?.user_id || session.client_reference_id;
  
  if (!userId) {
    console.error("No user_id in checkout session");
    return;
  }

  const subscriptionId = session.subscription as string;
  const customerId = session.customer as string;

  // Fetch subscription to get price details
  const subscription = await stripe.subscriptions.retrieve(subscriptionId) as any;
  const priceId = subscription.items.data[0]?.price.id;
  const tier = PRICE_ID_TO_TIER[priceId] || "free";

  await upsertEntitlement(userId, {
    tier,
    status: "active",
    stripe_customer_id: customerId,
    stripe_subscription_id: subscriptionId,
    current_period_end: subscription.current_period_end ? new Date(subscription.current_period_end * 1000).toISOString() : null,
  });

  console.log(`Entitlement created for user ${userId}: ${tier}`);
}

async function handleSubscriptionUpdate(subscription: any) {
  const userId = subscription.metadata?.user_id;
  
  if (!userId) {
    console.error("No user_id in subscription metadata");
    return;
  }

  const priceId = subscription.items.data[0]?.price.id;
  const tier = PRICE_ID_TO_TIER[priceId] || "free";
  const status = subscription.status === "active" ? "active" : 
                 subscription.status === "past_due" ? "past_due" :
                 subscription.status === "incomplete" ? "incomplete" : "canceled";

  await upsertEntitlement(userId, {
    tier,
    status,
    stripe_subscription_id: subscription.id,
    current_period_end: subscription.current_period_end ? new Date(subscription.current_period_end * 1000).toISOString() : null,
  });

  console.log(`Entitlement updated for user ${userId}: ${tier} (${status})`);
}

async function handleSubscriptionDeleted(subscription: Stripe.Subscription) {
  const userId = subscription.metadata?.user_id;
  
  if (!userId) {
    console.error("No user_id in subscription metadata");
    return;
  }

  await upsertEntitlement(userId, {
    tier: "free",
    status: "canceled",
    stripe_subscription_id: null,
    current_period_end: null,
  });

  console.log(`Subscription canceled for user ${userId}`);
}

async function handlePaymentFailed(invoice: any) {
  const subscriptionId = typeof invoice.subscription === 'string' ? invoice.subscription : invoice.subscription?.id;
  
  if (!subscriptionId) {
    return;
  }

  const subscription = await stripe.subscriptions.retrieve(subscriptionId);
  const userId = subscription.metadata?.user_id;
  
  if (!userId) {
    console.error("No user_id in subscription metadata");
    return;
  }

  await upsertEntitlement(userId, {
    status: "past_due",
  });

  console.log(`Payment failed for user ${userId}`);
}
