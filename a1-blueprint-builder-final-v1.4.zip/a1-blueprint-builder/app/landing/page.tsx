import Link from "next/link";

export default function LandingPage() {
  return (
    <div className="container" style={{ textAlign: "center", padding: "80px 24px" }}>
      <div className="badge ok" style={{ marginBottom: 20 }}>v1.2 Production Ready</div>
      <h1 style={{ fontSize: 56, fontWeight: 900, lineHeight: 1.1, marginBottom: 24 }}>
        Build Enterprise Blueprints <br />
        <span style={{ color: "#1d4ed8" }}>In Seconds.</span>
      </h1>
      <p style={{ fontSize: 18, color: "#9fb0c3", maxWidth: 600, margin: "0 auto 40px", lineHeight: 1.6 }}>
        The A-1 Router-Prime Blueprint Builder automates the transition from intake to production-ready specs. 
        Anti-cyclical, terminal, and production-grade.
      </p>
      
      <div className="row" style={{ justifyContent: "center", gap: 16 }}>
        <Link href="/auth/signup" className="btn" style={{ padding: "14px 28px", fontSize: 16 }}>
          Get Started Free
        </Link>
        <Link href="/pricing" className="btn secondary" style={{ padding: "14px 28px", fontSize: 16 }}>
          View Pricing
        </Link>
      </div>

      <div style={{ marginTop: 80, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: 30 }}>
        <div className="card">
          <h3 className="h2">Anti-Cyclical</h3>
          <p className="small">Guaranteed to end in NEXT FILE BATCH or FINAL SHIP PACKAGE. No infinite loops.</p>
        </div>
        <div className="card">
          <h3 className="h2">Enterprise Ready</h3>
          <p className="small">Built-in safety scans, Zod validation, and structured output enforcement.</p>
        </div>
        <div className="card">
          <h3 className="h2">Local-First</h3>
          <p className="small">Your history stays in your browser. Privacy by design, performance by default.</p>
        </div>
      </div>
    </div>
  );
}
