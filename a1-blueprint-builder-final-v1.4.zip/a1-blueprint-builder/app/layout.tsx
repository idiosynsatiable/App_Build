import "./globals.css";

export const metadata = {
  title: "A-1 Blueprint Builder",
  description: "Router-Prime + Personas + Integrator runner (anti-cyclical)"
};

import Link from "next/link";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <nav style={{ borderBottom: "1px solid #1b2430", padding: "12px 0", background: "#0f141b" }}>
          <div className="container row" style={{ justifyContent: "space-between" }}>
            <Link href="/" style={{ textDecoration: "none" }}>
              <div className="h2" style={{ margin: 0 }}>A-1 Blueprint Builder</div>
            </Link>
            <div className="row" style={{ gap: 20 }}>
              <Link href="/dashboard" className="small">Dashboard</Link>
              <Link href="/pricing" className="small">Pricing</Link>
              <Link href="/admin" className="small">Admin</Link>
            </div>
          </div>
        </nav>
        <div className="container" style={{ minHeight: "calc(100vh - 120px)", padding: "40px 24px" }}>
          {children}
        </div>
        <footer style={{ borderTop: "1px solid #1b2430", padding: "40px 0", marginTop: 80, background: "#0f141b" }}>
          <div className="container row" style={{ justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <div className="h2" style={{ margin: 0 }}>A-1 Blueprint Builder</div>
              <p className="small">Production-ready enterprise blueprints.</p>
            </div>
            <div className="row" style={{ gap: 40 }}>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <span className="small" style={{ fontWeight: "bold", color: "#e7edf5" }}>Product</span>
                <Link href="/pricing" className="small">Pricing</Link>
                <Link href="/landing" className="small">Features</Link>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <span className="small" style={{ fontWeight: "bold", color: "#e7edf5" }}>Legal</span>
                <Link href="/docs/PRIVACY.md" className="small">Privacy</Link>
                <Link href="/docs/TERMS.md" className="small">Terms</Link>
              </div>
            </div>
          </div>
          <div className="container" style={{ marginTop: 40 }}>
            <p className="small" style={{ opacity: 0.5 }}>
              © 2026 A-1 Blueprint Builder. Safety: Refuses malware/hacking/illicit C2.
            </p>
          </div>
        </footer>
      </body>
    </html>
  );
}
