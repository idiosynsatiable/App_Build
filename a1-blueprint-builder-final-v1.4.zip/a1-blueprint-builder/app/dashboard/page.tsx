"use client";

import { useState, useEffect } from "react";
import { createClient } from "@/lib/supabase/client";
import Link from "next/link";

export default function UserDashboard() {
  const [user, setUser] = useState<any>(null);
  const [entitlement, setEntitlement] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const supabase = createClient();

  useEffect(() => {
    async function loadData() {
      const { data: { user } } = await supabase.auth.getUser();
      setUser(user);
      
      if (user) {
        const { data } = await supabase
          .from("entitlements")
          .select("*")
          .eq("user_id", user.id)
          .single();
        setEntitlement(data);
      }
      setLoading(false);
    }
    loadData();
  }, []);

  async function handlePortal() {
    const res = await fetch("/api/stripe/portal", { method: "POST" });
    const data = await res.json();
    if (data.url) window.location.href = data.url;
  }

  if (loading) return <div className="container">Loading...</div>;
  if (!user) return <div className="container">Please <Link href="/auth/login" className="ok">sign in</Link> to view your dashboard.</div>;

  return (
    <div className="container">
      <h1 className="h1">Welcome, {user.email}</h1>
      
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 20, marginTop: 20 }}>
        <div className="card">
          <h2 className="h2">Subscription</h2>
          <div className="kv">
            <span>Tier</span>
            <span className="badge ok" style={{ textTransform: "uppercase" }}>{entitlement?.tier || "free"}</span>
          </div>
          <div className="kv">
            <span>Status</span>
            <span className="ok">{entitlement?.status || "active"}</span>
          </div>
          <div className="kv">
            <span>Usage</span>
            <span>{entitlement?.compilations_used || 0} compilations this month</span>
          </div>
          <button className="btn secondary" style={{ width: "100%", marginTop: 20 }} onClick={handlePortal}>
            Manage Billing
          </button>
        </div>

        <div className="card">
          <h2 className="h2">Quick Actions</h2>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <Link href="/" className="btn" style={{ textAlign: "center" }}>
              New Compilation
            </Link>
            <Link href="/pricing" className="btn secondary" style={{ textAlign: "center" }}>
              Upgrade Plan
            </Link>
          </div>
        </div>
      </div>

      <div className="card" style={{ marginTop: 20 }}>
        <h2 className="h2">Recent History</h2>
        <p className="small">Your compilation history is stored locally in this browser for privacy.</p>
        {/* History component is already in app/page.tsx, we could refactor it into a shared component */}
        <div style={{ marginTop: 10 }}>
          <Link href="/" className="ok small">View History on Main Page →</Link>
        </div>
      </div>
    </div>
  );
}
