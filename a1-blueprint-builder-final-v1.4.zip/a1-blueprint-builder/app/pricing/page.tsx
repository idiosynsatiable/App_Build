"use client";

import { useState } from "react";
import { STRIPE_PLANS, PlanId } from "@/lib/stripe/config";

export default function PricingPage() {
  const [loading, setLoading] = useState<PlanId | null>(null);

  async function handleSubscribe(planId: PlanId) {
    setLoading(planId);
    try {
      const res = await fetch("/api/stripe/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planId }),
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        alert(data.error || "Failed to start checkout");
      }
    } catch (err) {
      alert("An error occurred");
    } finally {
      setLoading(null);
    }
  }

  return (
    <div className="container">
      <div style={{ textAlign: "center", marginBottom: 40 }}>
        <h1 className="h1">Choose Your Plan</h1>
        <p className="small">Unlock the full power of the A-1 Blueprint Builder.</p>
      </div>

      <div style={{ 
        display: "grid", 
        gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", 
        gap: 20 
      }}>
        {(Object.keys(STRIPE_PLANS) as PlanId[]).map((id) => {
          const plan = STRIPE_PLANS[id];
          return (
            <div key={id} className="card" style={{ 
              display: "flex", 
              flexDirection: "column", 
              justifyContent: "space-between",
              border: id === "pro" ? "2px solid #1d4ed8" : "1px solid #1b2430"
            }}>
              <div>
                <div className="row" style={{ justifyContent: "space-between" }}>
                  <h2 className="h2">{plan.name}</h2>
                  {id === "pro" && <span className="badge ok">Popular</span>}
                </div>
                <div style={{ fontSize: 32, fontWeight: 800, margin: "10px 0" }}>
                  ${plan.price}<span style={{ fontSize: 16, fontWeight: 400, color: "#9fb0c3" }}>/mo</span>
                </div>
                <ul style={{ padding: "0 0 0 20px", margin: "20px 0", color: "#e7edf5" }}>
                  {plan.features.map((f, i) => (
                    <li key={i} style={{ marginBottom: 8, fontSize: 14 }}>{f}</li>
                  ))}
                </ul>
              </div>
              <button 
                className="btn" 
                style={{ width: "100%", marginTop: 20 }}
                disabled={loading !== null}
                onClick={() => handleSubscribe(id)}
              >
                {loading === id ? "Redirecting..." : `Get ${plan.name}`}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
