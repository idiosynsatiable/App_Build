"use client";

import { useState, useEffect } from "react";
import { createClient } from "@/lib/supabase/client";

export default function AdminDashboard() {
  const [secrets, setSecrets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [newSecret, setNewSecret] = useState({ name: "", value: "", description: "" });
  const [user, setUser] = useState<any>(null);

  const supabase = createClient();

  useEffect(() => {
    async function checkAuth() {
      const { data: { user } } = await supabase.auth.getUser();
      setUser(user);
      if (user) {
        fetchSecrets();
      } else {
        setLoading(false);
      }
    }
    checkAuth();
  }, []);

  async function fetchSecrets() {
    try {
      const res = await fetch("/api/admin/secrets");
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setSecrets(data.secrets || []);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleSave() {
    try {
      const res = await fetch("/api/admin/secrets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newSecret),
      });
      if (!res.ok) throw new Error("Failed to save");
      setNewSecret({ name: "", value: "", description: "" });
      fetchSecrets();
    } catch (err: any) {
      setError(err.message);
    }
  }

  async function handleDelete(name: string) {
    if (!confirm(`Delete ${name}?`)) return;
    try {
      const res = await fetch("/api/admin/secrets", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      });
      if (!res.ok) throw new Error("Failed to delete");
      fetchSecrets();
    } catch (err: any) {
      setError(err.message);
    }
  }

  if (loading) return <div className="container">Loading...</div>;
  if (!user) return <div className="container">Please sign in.</div>;

  return (
    <div className="container">
      <h1 className="h1">Admin Secrets Dashboard</h1>
      <p className="small" style={{ marginBottom: 20 }}>
        Manage API keys and service configurations securely.
      </p>

      {error && <div className="card err" style={{ marginBottom: 20 }}>{error}</div>}

      <div className="card" style={{ marginBottom: 20 }}>
        <h2 className="h2">Add New Secret</h2>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <input
            className="ta"
            style={{ minHeight: 40 }}
            placeholder="Key Name (e.g., STRIPE_SECRET_KEY)"
            value={newSecret.name}
            onChange={(e) => setNewSecret({ ...newSecret, name: e.target.value })}
          />
          <input
            className="ta"
            style={{ minHeight: 40 }}
            placeholder="Key Value"
            type="password"
            value={newSecret.value}
            onChange={(e) => setNewSecret({ ...newSecret, value: e.target.value })}
          />
          <input
            className="ta"
            style={{ minHeight: 40 }}
            placeholder="Description (optional)"
            value={newSecret.description}
            onChange={(e) => setNewSecret({ ...newSecret, description: e.target.value })}
          />
          <button className="btn" onClick={handleSave}>Save Secret</button>
        </div>
      </div>

      <div className="card">
        <h2 className="h2">Stored Secrets</h2>
        {secrets.length === 0 ? (
          <p className="small">No secrets stored in database.</p>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {secrets.map((s) => (
              <div key={s.key_name} className="kv" style={{ alignItems: "center" }}>
                <div>
                  <div style={{ fontWeight: "bold" }}>{s.key_name}</div>
                  <div className="small">{s.description || "No description"}</div>
                </div>
                <div className="row">
                  <span className="badge ok">Stored</span>
                  <button 
                    className="btn secondary" 
                    style={{ padding: "4px 8px", fontSize: 12 }}
                    onClick={() => handleDelete(s.key_name)}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
